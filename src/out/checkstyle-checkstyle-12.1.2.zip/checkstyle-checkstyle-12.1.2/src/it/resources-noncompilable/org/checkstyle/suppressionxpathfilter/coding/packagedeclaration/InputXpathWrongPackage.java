// non-compiled with javac: wrong package. Used for Testing purpose.
package my.packagename.mismatch.with.folder; // warn

public class InputXpathWrongPackage {
	// code
}

package org.checkstyle.suppressionxpathfilter.PACKAGENAME; // warn

public class InputXpathPackageNameThree {
}

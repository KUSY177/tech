package com.google.checkstyle.test.chapter3filestructure.toolongpackagetotestcoveragegooglesjavastylerule; // ok

final class InputPackageStatementLongName {}
